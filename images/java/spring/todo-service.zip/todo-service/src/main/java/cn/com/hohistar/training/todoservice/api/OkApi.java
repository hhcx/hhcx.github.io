package cn.com.hohistar.training.todoservice.api;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class OkApi {

    @RequestMapping("/ok")
    public String ok() {
        return "ok";
    }

}
