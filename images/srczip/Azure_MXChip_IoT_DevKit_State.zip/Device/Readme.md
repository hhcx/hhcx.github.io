# DevKitState

Please follow the [guide](https://github.com/Microsoft/vscode-iot-workbench/blob/master/docs/iot-devkit/devkit-state.md) to run DevKitState in IoT Workbench.