package cn.com.hohistar.cloud.order.api;

import cn.com.hohistar.cloud.order.biz.OrderMasterBiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderMasterApi {

    @Autowired
    private OrderMasterBiz orderBiz;

    @GetMapping("/confirm")
    public String confirmOrder(@RequestParam("prod") String prod) {

        orderBiz.confimOrder(prod, 20.0, 100);

        return "ok";
    }

}
