package cn.com.hohistar.cloud.order.repository;

import cn.com.hohistar.cloud.order.model.OrderMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderMasterRepos extends JpaRepository<OrderMaster, Integer> {

}

