package cn.com.hohistar.cloud.order.biz;


import cn.com.hohistar.cloud.order.model.OrderMaster;
import cn.com.hohistar.cloud.order.repository.OrderMasterRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.math.BigDecimal;

@Service
public class OrderMasterBiz {

    @Autowired
    private OrderMasterRepos orderRepos;

    @Transactional
    public void confimOrder(String prod, Double amount, Integer allCount) {

        OrderMaster order = new OrderMaster();
        order.setProduct(prod);
        order.setAmount(amount);
        order.setAllCount(allCount);

        orderRepos.save(order);

    }



}
