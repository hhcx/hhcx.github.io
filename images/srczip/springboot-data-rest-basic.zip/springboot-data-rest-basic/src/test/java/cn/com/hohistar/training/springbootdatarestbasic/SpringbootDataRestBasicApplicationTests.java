package cn.com.hohistar.training.springbootdatarestbasic;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootDataRestBasicApplicationTests {

	@Test
	void contextLoads() {
	}

}
