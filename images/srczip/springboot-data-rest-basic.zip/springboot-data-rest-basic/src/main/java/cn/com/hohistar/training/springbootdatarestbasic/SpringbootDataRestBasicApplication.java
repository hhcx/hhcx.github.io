package cn.com.hohistar.training.springbootdatarestbasic;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootDataRestBasicApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringbootDataRestBasicApplication.class, args);
	}

}
