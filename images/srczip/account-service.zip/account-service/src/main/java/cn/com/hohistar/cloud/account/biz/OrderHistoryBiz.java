package cn.com.hohistar.cloud.account.biz;


import cn.com.hohistar.cloud.account.model.OrderHistory;
import cn.com.hohistar.cloud.account.repos.OrderHistoryRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class OrderHistoryBiz {

    @Autowired
    private OrderHistoryRepos orderHistoryRepos;

    @Transactional
    public void handlOrder(String prod, Integer orderId, Integer allCount) {

        OrderHistory order = new OrderHistory();
        order.setProduct(prod);
        order.setOrderId(orderId);
        order.setAllCount(allCount);

        orderHistoryRepos.save(order);
    }
}

