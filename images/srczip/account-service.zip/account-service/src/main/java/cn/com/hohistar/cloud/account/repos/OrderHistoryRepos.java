package cn.com.hohistar.cloud.account.repos;


import cn.com.hohistar.cloud.account.model.OrderHistory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderHistoryRepos extends JpaRepository<OrderHistory, Integer> {
}

