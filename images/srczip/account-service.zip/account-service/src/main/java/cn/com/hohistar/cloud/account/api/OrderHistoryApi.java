package cn.com.hohistar.cloud.account.api;


import cn.com.hohistar.cloud.account.biz.OrderHistoryBiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class OrderHistoryApi {

    @Autowired
    private OrderHistoryBiz orderHistoryBiz;


    @GetMapping("/handleOrder")
    public String handleOrder(@RequestParam("prod") String prod, @RequestParam("orderId") Integer orderId, @RequestParam("count") Integer count) {

        orderHistoryBiz.handlOrder(prod, orderId, count);

        return "ok";
    }
}

