package cn.com.hohistar.cloud.store.repos;

import cn.com.hohistar.cloud.store.model.StoreMaster;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface StoreMasterRepos extends JpaRepository<StoreMaster, Integer> {
}
