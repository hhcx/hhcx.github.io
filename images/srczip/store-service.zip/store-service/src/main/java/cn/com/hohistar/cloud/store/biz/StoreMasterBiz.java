package cn.com.hohistar.cloud.store.biz;


import cn.com.hohistar.cloud.store.model.StoreMaster;
import cn.com.hohistar.cloud.store.repos.StoreMasterRepos;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;

@Service
public class StoreMasterBiz {

    @Autowired
    private StoreMasterRepos storeMasterRepos;

    @Transactional
    public void handlOrder(String prod, Integer orderId, Integer allCount) {

        StoreMaster store = new StoreMaster();
        store.setProduct(prod);
        store.setOrderId(orderId);
        store.setAllCount(allCount);

        storeMasterRepos.save(store);
    }
}
