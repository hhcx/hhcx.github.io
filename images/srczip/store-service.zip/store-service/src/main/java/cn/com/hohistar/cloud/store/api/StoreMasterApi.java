package cn.com.hohistar.cloud.store.api;


import cn.com.hohistar.cloud.store.biz.StoreMasterBiz;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class StoreMasterApi {

    @Autowired
    private StoreMasterBiz storeMasterBiz;


    @GetMapping("/handleOrder")
    public String handleOrder(@RequestParam("prod") String prod, @RequestParam("orderId") Integer orderId, @RequestParam("count") Integer count) {

        storeMasterBiz.handlOrder(prod, orderId, count);

        return "ok";
    }
}
