# GetStarted

This is the GetStarted tutorial for [IoT DevKit](https://aka.ms/devkit), please follow the [guide](https://github.com/Microsoft/vscode-iot-workbench/blob/master/docs/iot-devkit/devkit-get-started.md) to run it in [IoT Workbench](https://aka.ms/iot-workbench).
